/*
           version:1.0.1
           url:''
           payurl:''
           date:
 */
alert("我是外部弹框文件！")